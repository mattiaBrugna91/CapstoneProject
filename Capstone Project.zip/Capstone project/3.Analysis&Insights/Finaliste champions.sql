WITH SquadrePartecipanti AS (
    -- lista delle squadre partecipanti per ogni stagione
    SELECT DISTINCT SEASON, HOME_TEAM AS SQUADRA, VALORE_DI_MERCATO
    FROM matches M
    INNER JOIN valori_mercato VM
    ON M.HOME_TEAM = VM.SQUADRA
    WHERE SEASON = "2016-2017"
),
SquadreCount AS (
    -- numero di partite e valore di mercato per le squadre partecipanti
    SELECT 
        sp.SEASON,
        sp.SQUADRA,
        COUNT(*) AS NUM_PARTITE,
        vm.VALORE_DI_MERCATO
    FROM SquadrePartecipanti sp
    JOIN matches m ON sp.SEASON = m.SEASON AND (sp.SQUADRA = m.HOME_TEAM OR sp.SQUADRA = m.AWAY_TEAM)
    JOIN valori_mercato vm ON sp.SQUADRA = vm.SQUADRA
    GROUP BY sp.SEASON, sp.SQUADRA, vm.VALORE_DI_MERCATO
),
SquadreClassificate AS (
    -- posizione delle squadre partecipanti in base al numero di partite giocate
    SELECT
        SEASON,
        SQUADRA,
        NUM_PARTITE,
        VALORE_DI_MERCATO,
        ROW_NUMBER() OVER (PARTITION BY SEASON ORDER BY NUM_PARTITE DESC) AS Posizione
    FROM SquadreCount
),
ClassificaValore AS (
    -- posizione in classifica dei valori delle rose solo per le squadre partecipanti
    SELECT
        SQUADRA,
        VALORE_DI_MERCATO,
        ROW_NUMBER() OVER (ORDER BY VALORE_DI_MERCATO DESC) AS posizioneValore
    FROM SquadrePartecipanti
)
-- La query principale che unisce tutte le CTE
SELECT 
    sp.SEASON,
    sc.SQUADRA,
    sc.NUM_PARTITE,
    sc.VALORE_DI_MERCATO,
    cv.posizioneValore AS POSIZIONE_CLASSIFICA_VALORE
FROM SquadrePartecipanti sp
JOIN SquadreClassificate sc ON sp.SEASON = sc.SEASON AND sp.SQUADRA = sc.SQUADRA
JOIN ClassificaValore cv ON sc.SQUADRA = cv.SQUADRA
WHERE Posizione <= 2
ORDER BY sp.SEASON, sc.SQUADRA;
