DELIMITER //

CREATE PROCEDURE GetGoalsByTeamAndSeason(
    IN pSeason VARCHAR(10),
    IN pTeam VARCHAR(50)
)
BEGIN
    DECLARE totalGoals INT;
    
    SELECT 
        SUM(CASE WHEN HOME_TEAM = pTeam THEN HOME_TEAM_SCORE ELSE 0 END +
            CASE WHEN AWAY_TEAM = pTeam THEN AWAY_TEAM_SCORE ELSE 0 END) 
        INTO totalGoals
    FROM matches
    WHERE SEASON = pSeason;

    SELECT CONCAT('Total goals scored by ', pTeam, ' in season ', pSeason, ': ', totalGoals) AS Result;
END;
//

DELIMITER ;

CALL GetGoalsByTeamAndSeason('2021-2022', 'Real Madrid');


