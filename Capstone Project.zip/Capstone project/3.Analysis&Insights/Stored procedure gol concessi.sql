DELIMITER //

CREATE PROCEDURE GetGoalsConcededByTeamAndSeason(
    IN pTeam VARCHAR(255),
    IN pSeason VARCHAR(10)
)
BEGIN
    DECLARE goalsConceded INT;

    SELECT 
        SUM(CASE
            WHEN HOME_TEAM = pTeam THEN AWAY_TEAM_SCORE
            WHEN AWAY_TEAM = pTeam THEN HOME_TEAM_SCORE
            ELSE 0
        END) INTO goalsConceded
    FROM matches
    WHERE SEASON = pSeason
        AND (HOME_TEAM = pTeam OR AWAY_TEAM = pTeam);

    SELECT CONCAT('Total goals conceded by ', pTeam, ' in season ', pSeason, ': ', goalsConceded) AS Result;
END;
//

DELIMITER ;



CALL GetGoalsConcededByTeamAndSeason('Juventus', '2016-2017');

