-- Configurazione dell'autenticazione 'mysql_native_password', per ottenere la compatibilità con il modulo mysql.connector e lavorare con python
ALTER USER 'root'@'localhost' IDENTIFIED WITH 'mysql_native_password' BY '0000';

-- Creazione della tabella "matches"
CREATE TABLE matches (
    MATCH_ID VARCHAR(10) PRIMARY KEY,
    SEASON NVARCHAR(10),
    MATCH_DATE DATE,
    HOME_TEAM VARCHAR(50),
    AWAY_TEAM VARCHAR(50),
    HOME_TEAM_SCORE INT,
    AWAY_TEAM_SCORE INT
);

-- Creazione della tabella "valori_mercato"
CREATE TABLE valori_mercato (
	SQUADRA VARCHAR(50) PRIMARY KEY,
    VALORE_DI_MERCATO float
);

-- Aggiunta del vincolo di chiave esterna sulla tabella "matches"
ALTER TABLE matches
ADD CONSTRAINT FK_matches_home_team FOREIGN KEY (HOME_TEAM) REFERENCES valori_mercato (SQUADRA);