import openpyxl

# Carico il file Excel
file_path = 'Valori Mercato.xlsx' 
workbook = openpyxl.load_workbook(file_path)
sheet = workbook['Valori mercato'] 

# Inserisco l'indice della colonna Valore di Mercato
colonna_valore_mercato = 3  

# Itero attraverso le righe nel foglio
for row in sheet.iter_rows(min_row=2, max_row=sheet.max_row, min_col=colonna_valore_mercato, max_col=colonna_valore_mercato):
    for cell in row:
        valore_mercato = cell.value

        # Converto il valore in base al testo presente
        if 'mld' in valore_mercato:
            valore_mercato = float(valore_mercato.replace(' mld €', '')) * 1000000000
        elif 'mln' in valore_mercato:
            valore_mercato = float(valore_mercato.replace(' mln €', '')) * 1000000
        else:
            valore_mercato = float(valore_mercato.replace(',', ''))

        cell.value = valore_mercato

# Salvo il file modificato
modified_file_path = 'Valori_modificato.xlsx'
workbook.save(modified_file_path)

print("Conversione completata e file Excel modificato.")

