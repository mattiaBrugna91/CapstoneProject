import mysql.connector
import pandas as pd

# Connessione al database MySQL
connessione = mysql.connector.connect(
    host="localhost",
    user="root",
    password="0000",
    database="capstone",
    auth_plugin='mysql_native_password'
)

# Caricamento del DataFrame dal file Excel
df = pd.read_excel("Valori_mercato.xlsx", sheet_name="Valori")

# Creazione del cursore
cursor = connessione.cursor()

# Iterazione attraverso il DataFrame e inserimento dei dati nella tabella "matches"
for index, row in df.iterrows():
    query = "INSERT INTO Valori_mercato (SQUADRA, VALORE_DI_MERCATO) VALUES (%s, %s)"
    data = (row["Squadra"], row["Valore_di_mercato"])
    cursor.execute(query, data)

# Esecuzione del commit per salvare i dati nel database
connessione.commit()

# Chiusura del cursore e della connessione
cursor.close()
connessione.close()