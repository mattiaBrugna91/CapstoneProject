import mysql.connector
import pandas as pd

# Connessione al database MySQL
connessione = mysql.connector.connect(
    host="localhost",
    user="root",
    password="0000",
    database="capstone",
    auth_plugin='mysql_native_password'
)

# Caricamento del DataFrame dal file Excel
df = pd.read_excel("UEFA Champions League 2016-2022 Data.xlsx", sheet_name="matches")

# Creazione del cursore
cursor = connessione.cursor()

# Iterazione attraverso il DataFrame e inserimento dei dati nella tabella "matches"
for index, row in df.iterrows():
    query = "INSERT INTO matches (MATCH_ID, SEASON, MATCH_DATE, HOME_TEAM, AWAY_TEAM, HOME_TEAM_SCORE, AWAY_TEAM_SCORE) VALUES (%s, %s, %s, %s, %s, %s, %s)"
    data = (row["MATCH_ID"], row["SEASON"],row["DATE_TIME"], row["HOME_TEAM"], row["AWAY_TEAM"], row["HOME_TEAM_SCORE"], row["AWAY_TEAM_SCORE"])
    cursor.execute(query, data)

# Esecuzione del commit per salvare i dati nel database
connessione.commit()

# Chiusura del cursore e della connessione
cursor.close()
connessione.close()
