SELECT * FROM capstone.matches;
-- individuazione dei valori delle squadre scritte in modo diverso che non mi permettevano di inserire il vincolo di chiave esterna
SELECT m.HOME_TEAM, count(m.HOME_TEAM) as NUMERO
FROM matches m
LEFT JOIN valori_mercato v ON m.HOME_TEAM = v.SQUADRA
WHERE v.SQUADRA IS NULL
GROUP BY HOME_TEAM;
